package com.hakanaktas.mediaplayerproject;

public class User {
    public String nameSurname, email, password, mobile;

    public User() {

    }

    public User(String nameSurname, String email, String password, String mobile){
        this.nameSurname=nameSurname;
        this.email=email;
        this.password=password;
        this.mobile=mobile;
    }

}
